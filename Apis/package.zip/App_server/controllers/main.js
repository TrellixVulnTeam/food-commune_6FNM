const login=function(req,res){
    res.render('index');
};

module.exports=
{
    login
};